//
//  MagTekDemoAppDelegate.h
//  MagTekDemo
//
//  Created by MagTek on 4/21/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MagTekDemoViewController;

@interface MagTekDemoAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MagTekDemoViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MagTekDemoViewController *viewController;

@end

