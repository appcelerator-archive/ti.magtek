//
//  MagTekDemoViewController.m
//  MagTekDemo
//
//  Created by MagTek on 4/21/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "MagTekDemoViewController.h"
#import "MagTekSCRA.h"

@implementation MagTekDemoViewController



@synthesize revVersion, session, eaAccessory, dataFromiDynamo, deviceStatus;
@synthesize scrollView;
@synthesize EncTrack1, EncTrack2,EncTrack3,EncMP,KSN,MPStatus,DeviceSN;
@synthesize command;



- (IBAction) sendMessageToiDynamo:(id)sender
{
	
	NSLog(@"sendMessageToiDynamo");
	NSLog(@"command = %@", self.command.text);
	if (acc.connected)
	{
		
		
		
		NSOutputStream *currentoutputStream = [session outputStream];	
		int currentoutputstreamstatus = [currentoutputStream streamStatus];
		NSLog(@"Stream Status  %d", currentoutputstreamstatus);
		NSLog(@"Has Space Avaiable = %d", [currentoutputStream hasSpaceAvailable]);
		if (currentoutputstreamstatus == 0)
		{
			[[session outputStream] setDelegate:self];
			[[session outputStream] scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
			[[session outputStream] open];
			currentoutputStream = [session outputStream];	
			currentoutputstreamstatus = [currentoutputStream streamStatus];
			NSLog(@"Stream Status  %d", currentoutputstreamstatus);
			NSLog(@"Has Space Avaiable = %d", [currentoutputStream hasSpaceAvailable]);
		}
		
		NSString * outputData = [[NSString alloc] initWithString:self.command.text];
		
		outputData = [outputData stringByAppendingFormat:@"%c", 13];
			NSInteger returnValue = [[session outputStream] write:(const uint8_t*)[outputData UTF8String] maxLength:[outputData length]];
		NSLog(@"returnValue write = %d", returnValue);
		currentoutputstreamstatus = [currentoutputStream streamStatus];
		
		int hasspaceavailable = [currentoutputStream hasSpaceAvailable];
		NSLog(@"stop hasspaceavail=%d", hasspaceavailable);
		
	}	
	
}
- (BOOL)textFieldShouldReturn:(UITextField*)aTextField
{
    [aTextField resignFirstResponder];
    return YES;
}

- (void) displayReturnMessage
{
	//no more data to wait for, display it/use it
	NSLog(@"displayReturnMessage");
	UIAlertView *alert2 = [[UIAlertView alloc] initWithTitle:@"Data From iDynamo" message:dataFromiDynamo delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert2 show];
	[alert2 release];

}
#pragma mark -
#pragma mark Notifications for Connect/Disconnected

- (void)turnConnectionNotificationsOn 
{	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(DeviceConnected:)  name:EAAccessoryDidConnectNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(DeviceDisconnected:)  name:EAAccessoryDidDisconnectNotification object:nil];
	[[EAAccessoryManager sharedAccessoryManager] registerForLocalNotifications];
}

- (void)turnConnectionNotificationsOff 
{
	[[EAAccessoryManager sharedAccessoryManager] unregisterForLocalNotifications];  
	
	//[[EAAccessoryManager sharedAccessoryManager] registerForLocalNotifications];  
	
	NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    [notificationCenter removeObserver: self
								  name: EAAccessoryDidConnectNotification
								object: nil];
	
	[notificationCenter removeObserver: self
								  name: EAAccessoryDidDisconnectNotification
								object: nil];
}

#pragma mark  -
#pragma mark MSRAccessory

- (EAAccessory *) compatibleAccessory: (EAAccessoryManager *) manager {
	
	
	NSArray *accessories = [manager connectedAccessories];
    for (EAAccessory *obj in accessories) {
        if ([[obj protocolStrings] containsObject:iDynamo]) {
			return obj;
        }
    }
	
	return nil;
}

- (void)closeSession
{
	if(session)
	{
		[NSThread sleepForTimeInterval:1.0];
		
		[[session inputStream] close];
		[[session inputStream] removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
		[[session inputStream] setDelegate:nil];
		
		[[session outputStream] close];
		[[session outputStream] removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
		[[session outputStream] setDelegate:nil];
		
		[session release];
		session = nil;
	}
}


- (BOOL)establishSession 
{
	// close old session before open new one 
	[self closeSession];
	
	EAAccessory *obj = [self compatibleAccessory:[EAAccessoryManager sharedAccessoryManager]];
	
	if (obj) 
	{
		acc = obj;
		session = [[EASession alloc] initWithAccessory:acc forProtocol:iDynamo];
		
		if (session) 
		{
			self.deviceStatus.text = @"Device Connected";
			[[session inputStream] setDelegate:self];
			[[session inputStream] scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
			[[session inputStream] open];
			
			[[session outputStream] setDelegate:self];
			[[session outputStream] scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
			[[session outputStream] open];
			
		//	NSLog(@"NSStreamEventNone = 0, NSStreamEventOpenCompleted = 1 << 0,NSStreamEventHasBytesAvailable = 1 << 1,NSStreamEventHasSpaceAvailable = 1 << 2,NSStreamEventErrorOccurred = 1 << 3,NSStreamEventEndEncountered = 1 << 4");
			NSLog(@"  NSStreamStatusNotOpen = 0");
			NSLog(@"  NSStreamStatusOpening = 1");
			NSLog(@"  NSStreamStatusOpen = 2");
			NSLog(@"  NSStreamStatusReading = 3");
			NSLog(@"  NSStreamStatusWriting = 4");
			NSLog(@"  NSStreamStatusAtEnd = 5");
			NSLog(@"  NSStreamStatusClosed = 6");
			NSLog(@"  NSStreamStatusError = 7");	
			
			NSLog(@"Establish Session current output stream status = %d", [[session outputStream] streamStatus]);
			NSLog(@"Establish Session input output stream status = %d", [[session inputStream] streamStatus]);
			
			if ([[session outputStream] streamStatus] == 0)
			{
				[[session outputStream] open];
				NSLog(@"Establish Session current output stream status = %d", [[session outputStream] streamStatus]);
			}
			
			return YES;
		}
		else 
		{
			NSLog(@"session is nil...");
		}
	}
	return NO;
}

- (void)applicationWillTerminate:(NSNotification *)notification{
	
	NSLog(@"ApplicationWillTerminate");
	if ( session != nil)
	{
			[NSThread sleepForTimeInterval:1.0];
			NSLog(@"close sesssion");
			[[session outputStream] close];
			[[session inputStream]close];
			[[session outputStream] removeFromRunLoop:[NSRunLoop currentRunLoop]
											  forMode:NSDefaultRunLoopMode];
			[[session inputStream] removeFromRunLoop:[NSRunLoop currentRunLoop]
											 forMode:NSDefaultRunLoopMode];
			
			session = nil;
			
	}
	
}


- (void) DeviceConnected:(NSNotification *)pNotification
{
	//NSLog(@"******Device Connected Method");
	
	EAAccessory *connectedAccessory = [[pNotification userInfo] objectForKey:EAAccessoryKey];
	
	acc = connectedAccessory;
	
	[self establishSession];
	
	self.deviceStatus.text = @"Device Connected";
	
	/*EAAccessoryManager *manager = [pNotification object];
	if ([self compatibleAccessory:manager]) 
	{
		if ([self establishSession])
		{
			NSLog(@"Should output device connected");
			self.deviceStatus.text = @"Device Connected";
			
		}
	}*/
}

- (void) DeviceDisconnected:(NSNotification *)pNotification
{
	/*NSLog(@"******DeviceDisconnected Method");
	
	if (session != nil)
	{
		[[session outputStream] close];
		[[session inputStream]close];
		[[session outputStream] removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
		[[session inputStream] removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];

		
		
		session = nil;
		//[session release];
	}
	EAAccessoryManager *manager = [pNotification object];
	if ([self compatibleAccessory:manager] == nil) */
	 {
		//NSLog(@"Should output device Disconnected");
		self.deviceStatus.text = @"Device Disconnected";
		//[[self delegate] DeviceDisconnected:self];
	}
}




- (BOOL) detectConnectReader
{
	/*EAAccessoryManager *p = [EAAccessoryManager sharedAccessoryManager];
	[p registerForLocalNotifications];
	
	[self turnConnectionNotificationsOn];
	
	
	if ([self compatibleAccessory:p]) {
		if ([self establishSession])
		{		
			self.deviceStatus.text = @"Device Connected";
			return YES;
		}			
	}
	else{
		self.deviceStatus.text = @"Device Disconnected";
	}
	//return NO if no reader is detected and connected*/
	return NO;
	
	
}
- (void)displayData{
	
	NSLog(@"Read Data = %@", dataFromiDynamo);
		
	MagTekSCRA * pSCRA = [[MagTekSCRA alloc]init];
	
	if(pSCRA !=NULL)
	{
		
		[pSCRA setCardData:dataFromiDynamo];
		
		self.EncTrack1.text = [pSCRA getTrack1];
		self.EncTrack2.text = [pSCRA getTrack2];
		self.EncTrack3.text = [pSCRA getTrack3];
		self.EncMP.text = [pSCRA getMagnePrint];
		self.KSN.text = [pSCRA getKSN];
		self.MPStatus.text = [pSCRA getMagnePrintStatus];
		self.DeviceSN.text = [pSCRA getDeviceSerial];
		
		NSLog(@"Encrypted Track1 = %@", [pSCRA getTrack1]);
		NSLog(@"Encrypted Track2 = %@", [pSCRA getTrack2]);
		NSLog(@"Encrypted Track3 = %@", [pSCRA getTrack3]);
		NSLog(@"Encrypted MagnePrint = %@", [pSCRA getMagnePrint]);
		NSLog(@"MagnePrint Status = %@", [pSCRA getMagnePrintStatus]);
		NSLog(@"KSN = %@", [pSCRA getKSN]);
		NSLog(@"Device Serial Number = %@", [pSCRA getDeviceSerial]);
		
				
		[pSCRA release];		
	}
	//[ptCardData release];
	
	//NSArray *listSwipeData = [dataFromiDynamo componentsSeparatedByString:@"|"];
	
	
	
	//object at index 0 is the masked data
	
	
	
		
}

- (void) clearLabels
{
	self.EncTrack1.text = @"";
	self.EncTrack2.text = @"";
	self.EncTrack3.text = @"";
	self.EncMP.text = @"";
	self.KSN.text = @"";
	self.MPStatus.text = @"";
	self.DeviceSN.text = @"";
}


- (void) stream: (NSStream *)stream handleEvent: (NSStreamEvent)eventCode
{
	static BOOL waitForMoreData = NO;
	switch(eventCode)
	{
			
		case NSStreamEventNone:
			NSLog(@"NSStreamEventNone");
			break;
		case NSStreamEventOpenCompleted:
			NSLog(@"NSStreamEventOpenCompleted : %@", stream);
			break;
		case NSStreamEventHasBytesAvailable:
			NSLog(@"****************NSStreamEventHasBytesAvailable****************");
			
			uint8_t readBuf[1024];
			memset(readBuf, 0, sizeof(readBuf));
			//read input stream
			NSInteger numberRead = [ (NSInputStream *) stream read:readBuf maxLength:1024];
			
			NSString *tempString = [[NSString alloc] initWithFormat:@"%s",readBuf];
			NSLog(@"tempString = %@", tempString);
			[self clearLabels];
			//just collect/append the data for later parsing
			if (waitForMoreData)
			{
				// Wait for more data already set, second batch of data arrived
				[dataFromiDynamo appendString:tempString];
				waitForMoreData = NO;
				UIAlertView *alert2 = [[UIAlertView alloc] initWithTitle:@"Data From iDynamo" message:dataFromiDynamo delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
				//[alert2 show];
				[alert2 release];
				
				[self displayData];
			}
			else if (numberRead >= 493)
			{
				[dataFromiDynamo setString:@""];
				[dataFromiDynamo appendString: tempString];
				
				if ([tempString characterAtIndex:numberRead -1] != 'x')
				{
					//More data on the way, set flag to wait for it
					//NSLog(@"Close applicatin/session on purpose!");
					//exit(0);
					waitForMoreData = YES;
				}
				else
				{
					//no more data to wait for, display it/use it
					UIAlertView *alert2 = [[UIAlertView alloc] initWithTitle:@"Data From iDynamo" message:dataFromiDynamo delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
					//[alert2 show];
					[alert2 release];
					[self displayData];
				}
			}	
			else {
				NSLog(@"call displayReturnMessage from stream handle event");
				[dataFromiDynamo setString:@""];
				[dataFromiDynamo appendString:tempString];
				[self displayReturnMessage];
			}

			[tempString release];
			break;
		case NSStreamEventHasSpaceAvailable:
			break;
		case NSStreamEventErrorOccurred:
			NSLog(@"NSStreamEventErrorOccured");
			[stream close];
			[stream removeFromRunLoop:[NSRunLoop currentRunLoop]
							  forMode:NSDefaultRunLoopMode];
			[stream release];
			stream = nil; // stream is over, so reinit it
			
			NSLog(@"done NSStreamEventErrorOccured");
			
			break;
		case NSStreamEventEndEncountered:
			NSLog(@"NSStreamEventEndEncountered");
			break;
			
	}
}




#pragma mark -
#pragma mark ViewDidLoad, etc

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{	
	[self turnConnectionNotificationsOn];
	[self establishSession];
	
	UIApplication *app = [UIApplication sharedApplication];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillTerminate:) name:UIApplicationWillTerminateNotification object:app];
	
	
	
	[scrollView setContentSize:CGSizeMake(320,600)];
	
	[self clearLabels];
	
	
	/*if( [self detectConnectReader])
		self.deviceStatus.text = @"Device Connected";*/
	
	dataFromiDynamo =  [[NSMutableString alloc] init];
	
	self.revVersion.text = kRevVersion;
	self.command.delegate = self;
	
	[super viewDidLoad];
}



// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	
    return YES;// (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	// revVersion, session, eaAccessory, dataFromiDynamo;
	NSLog(@"viewDidUnload");

	self.revVersion = nil;
	self.session = nil;
	self.eaAccessory = nil;
	self.dataFromiDynamo = nil;
	self.deviceStatus = nil;
	self.scrollView = nil;
	self.EncTrack1 = nil;
	
	self.EncTrack2 = nil;
	self.EncTrack3 = nil;
	self.EncMP = nil;
	self.KSN = nil;
	self.MPStatus = nil;
	self.DeviceSN = nil;
}


- (void)dealloc {
	[scrollView release];
	[deviceStatus release];
	[revVersion release];
	[session release];
	[eaAccessory release];
	[dataFromiDynamo release];
	
	[EncTrack1 release];
	[EncTrack2 release];
	[EncTrack3 release];
	[EncMP release];
	[MPStatus release];
	[KSN release];
	[DeviceSN release];
    [super dealloc];
}

@end
