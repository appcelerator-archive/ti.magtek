//
//  MagTekSCRA.m
//  MagTekDemo
//
//  Created by Imran Jahanzeb on 3/7/11.
//  Copyright 2011 MagTek. All rights reserved.
//

#import "MagTekSCRA.h"


@implementation MagTekSCRA

- (void) setCardData: (NSString *)pCardData
{
	if(pCardData!=NULL)
	{
		m_strCardData=[[NSString alloc] initWithString:pCardData];
		m_aryCardData=[m_strCardData componentsSeparatedByString:@"|"];		
	}
}
- (void) clearCardData
{
	if(m_strCardData!=NULL)
	{
		[m_strCardData release];
	}
	m_aryCardData=NULL;		
	
}
- (NSString *) getCardData
{
	return m_strCardData;		
}
- (NSString *) getMaskedTracks
{
	if(m_aryCardData !=NULL)
	{
		return [m_aryCardData objectAtIndex:MASKED_TRACKDATA];		
	}
	return @"";	
}
- (NSString *) getTrack1
{
	if(m_aryCardData !=NULL)
	{
		return [m_aryCardData objectAtIndex:ENCRYPTED_TRACK1];		
	}
	return @"";	
}
- (NSString *) getTrack2
{
	if(m_aryCardData !=NULL)
	{
		return [m_aryCardData objectAtIndex:ENCRYPTED_TRACK2];
	}
	return @"";	
}
- (NSString *) getTrack3
{
	if(m_aryCardData !=NULL)
	{
		return [m_aryCardData objectAtIndex:ENCRYPTED_TRACK3];	
	}
	return @"";	
}
- (NSString *) getTrack1Masked
{
	if(m_aryCardData !=NULL)
	{
	}
	return @"";	
}
- (NSString *) getTrack2Masked
{
	if(m_aryCardData !=NULL)
	{
	}
	return @"";	
}
- (NSString *) getTrack3Masked
{
	if(m_aryCardData !=NULL)
	{
	}
	return @"";	
}
- (NSString *) getMagnePrint
{
	if(m_aryCardData !=NULL)
	{
		return [m_aryCardData objectAtIndex:ENCRYPTED_MAGNEPRINT];	
	}
	return @"";	
}
- (NSString *) getMagnePrintStatus
{
	if(m_aryCardData !=NULL)
	{
		return [m_aryCardData objectAtIndex:MAGNEPRINT_STATUS];	
	}
	return @"";	
}
- (NSString *) getDeviceSerial
{
	if(m_aryCardData !=NULL)
	{
		return [m_aryCardData objectAtIndex:DEVICE_SERIALNUMBER];	
	}
	return @"";	
}
- (NSString *) getSessionID
{
	if(m_aryCardData !=NULL)
	{
		return [m_aryCardData objectAtIndex:ENCRYPTED_SESSIONID];	
	}
	return @"";	
}
- (NSString *) getKSN
{
	if(m_aryCardData !=NULL)
	{
		return [m_aryCardData objectAtIndex:DEVICE_KSN];	
	}
	return @"";	
}

-(void)dealloc
{
	if(m_strCardData!=NULL)
	{
		[m_strCardData release];
		m_strCardData=NULL;
	}
	
}

@end
