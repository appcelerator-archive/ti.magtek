//
//  MagTekSCRA.h
//  MagTekDemo
//
//  Created by Imran Jahanzeb on 3/7/11.
//  Copyright 2011 MagTek. All rights reserved.
//
enum CardDataContent 

{
	MASKED_TRACKDATA,
	DEVICE_ENCRYPTION_STATUS,
	ENCRYPTED_TRACK1,
	ENCRYPTED_TRACK2,
	ENCRYPTED_TRACK3,
	MAGNEPRINT_STATUS,
	ENCRYPTED_MAGNEPRINT,
	DEVICE_SERIALNUMBER,
	ENCRYPTED_SESSIONID,
	DEVICE_KSN
	
	
};
@interface MagTekSCRA : NSObject 
{ 
	NSString *m_strCardData;
	NSArray  *m_aryCardData;	
}
- (void) setCardData: (NSString *)pCardData;
- (void) clearCardData;
- (NSString *) getCardData;
- (NSString *) getMaskedTracks;
- (NSString *) getTrack1;
- (NSString *) getTrack2;
- (NSString *) getTrack3;
- (NSString *) getTrack1Masked;
- (NSString *) getTrack2Masked;
- (NSString *) getTrack3Masked;
- (NSString *) getMagnePrint;
- (NSString *) getMagnePrintStatus;
- (NSString *) getDeviceSerial;
- (NSString *) getSessionID;
- (NSString *) getKSN;

@end
