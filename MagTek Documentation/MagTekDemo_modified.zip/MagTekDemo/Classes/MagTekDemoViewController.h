//
//  MagTekDemoViewController.h
//  MagTekDemo
//
//  Created by MagTek on 4/21/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//


#import <UIKit/UIKit.h>
//For communicating with External Accessories like the iDynamo
#import <ExternalAccessory/ExternalAccessory.h>


//SDKProtocolID String
#define iDynamo @"com.magtek.idynamo"
#define kRevVersion @"rev. 1.0.0.2"



@interface MagTekDemoViewController : UIViewController <UITextFieldDelegate, UIApplicationDelegate, NSStreamDelegate> 
{	
	UILabel *revVersion;
	UILabel *deviceStatus;
	//UITextField *deviceStatus;
	EAAccessory *acc;
	EASession *session;
	EAAccessoryManager *eaAccessory;
	
	NSMutableString *dataFromiDynamo;
	
	UILabel *EncTrack1;
	
	UIScrollView *scrollView;
	
	UILabel *EncTrack2;
	UILabel *EncTrack3;
	UILabel *EncMP;
	UILabel *KSN;
	UILabel *MPStatus;
	UILabel *DeviceSN;
	
	UITextField *command;
	
	
}

@property (nonatomic, retain) IBOutlet UITextField *command;
@property (nonatomic, retain) IBOutlet UILabel *revVersion;
@property (nonatomic, retain) IBOutlet UILabel *deviceStatus;
@property (nonatomic, retain) EASession *session;
@property (nonatomic, retain) EAAccessoryManager *eaAccessory;

@property (nonatomic, retain) NSMutableString *dataFromiDynamo;
@property (nonatomic, retain) IBOutlet UIScrollView *scrollView;
@property (nonatomic, retain) IBOutlet UILabel *EncTrack1;
@property (nonatomic, retain) IBOutlet UILabel *EncTrack2;
@property (nonatomic, retain) IBOutlet UILabel *EncTrack3;
@property (nonatomic, retain) IBOutlet UILabel *EncMP;
@property (nonatomic, retain) IBOutlet UILabel *KSN;
@property (nonatomic, retain) IBOutlet UILabel *MPStatus;
@property (nonatomic, retain) IBOutlet UILabel *DeviceSN;

- (void)applicationWillTerminate:(NSNotification *)notification;
- (IBAction) sendMessageToiDynamo:(id)sender;
- (BOOL)textFieldShouldReturn:(UITextField *)aTextField;
- (BOOL) detectConnectReader;
- (void) turnConnectionNotificationsOn;
- (void) turnConnectionNotificationsOff;
- (BOOL) establishSession;
- (void)closeSession;
- (EAAccessory *) compatibleAccessory: (EAAccessoryManager *) manager;
- (void) clearLabels;

@end

