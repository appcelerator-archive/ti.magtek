//
//  MagTekSCRA.h
//  MagTekDemo
//
//  Created by Imran Jahanzeb on 1/4/11.
//  Copyright 2011 MagTek. All rights reserved.
//
enum MTSCRACardDataContent 

{
	MASKED_TRACKDATA,
	DEVICE_ENCRYPTION_STATUS,
	ENCRYPTED_TRACK1,
	ENCRYPTED_TRACK2,
	ENCRYPTED_TRACK3,
	MAGNEPRINT_STATUS,
	ENCRYPTED_MAGNEPRINT,
	DEVICE_SERIALNUMBER,
	ENCRYPTED_SESSIONID,
	DEVICE_KSN		
};

@interface MagTekSCRA : NSObject 
{ 
	NSString *m_strCardData;	
	NSArray  *m_aryCardData;	
	NSArray  *m_aryMaskedTracks;	
}
// Sets the card data that is retrieved fron the iDynamo
- (void) setCardData: (NSString *)pCardData;
// Clears the card data that is stored through the setCardData function
- (void) clearCardData;
// Retrieves the existing stored card data
- (NSString *) getCardData;
//Retrieves existing stored Masked data
- (NSString *) getMaskedTracks;
//Retrieve Encrypted Track1 if any
- (NSString *) getTrack1;
//Retrieve Encrypted Track2 if any
- (NSString *) getTrack2;
//Retrieve Encrypted Track3 if any
- (NSString *) getTrack3;
//Retrieve Masked Track1 if any
- (NSString *) getTrack1Masked;
//Retrieve Masked Track1 if any
- (NSString *) getTrack2Masked;
//Retrieve Masked Track2 if any
- (NSString *) getTrack3Masked;
//Retrieve Encrypted MagnePrint
- (NSString *) getMagnePrint;
//Retrieve MagnePrint Status
- (NSString *) getMagnePrintStatus;
//Retrieve Device Serial Number
- (NSString *) getDeviceSerial;
//Retrieve Session ID
- (NSString *) getSessionID;
//Retrieve Key Serial Number
- (NSString *) getKSN;

@end
